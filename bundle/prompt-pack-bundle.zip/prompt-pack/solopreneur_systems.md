# Solo Founder Systems Prompt Pack
P1 (plan): 'Given my goal {goal}, output a 5-step weekly operating loop as a table with day|task|metric.'
P2 (money): 'From this revenue CSV, list the top 3 cost leaks and one fix each.'
P3 (content): 'Turn these 3 bullet notes into a 200-word LinkedIn post with a hook and a question close.'
P4 (decide): 'Score this task 1-10 on asset/friction/capability/optionality. Recommend do/delegate/drop.'
