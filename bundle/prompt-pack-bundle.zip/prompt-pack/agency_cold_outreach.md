# Cold Outreach Prompt Pack for Agencies
P1 (research): 'From this lead's website URL, return JSON {niche, pain_point, offer_angle}. Under 60 words.'
P2 (first line): 'Write 3 subject lines for a cold email to a {niche} owner. Each under 40 chars, no spam words.'
P3 (body): 'Write a 90-word cold email. Hook with their pain. One CTA. No 'I hope this finds you'.'
P4 (follow-up): 'Write a 2-line follow-up referencing the original offer. Friendly, not pushy.'
