# Quickstart
1. Pick a vertical (agency / solopreneur / freelancer).
2. Run P1 then P2 then P3 in your model of choice.
3. Paste output into your CRM / email / Upwork.
4. Track replies; iterate the prompt that converts worst.
