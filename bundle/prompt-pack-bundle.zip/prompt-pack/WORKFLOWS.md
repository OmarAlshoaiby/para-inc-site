# Chained Recipes
R1: P1 research -> P2 subject -> P3 body -> send. (full cold email in 4 prompts)
R2: P1 plan -> P4 decide -> execute top task. (weekly loop)
R3: P1 scope -> P2 proposal -> P3 price -> P4 close. (full freelance pitch)
