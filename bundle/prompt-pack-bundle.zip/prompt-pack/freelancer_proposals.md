# Freelancer Proposal Prompt Pack
P1 (scope): 'From this client brief, extract: deliverable, timeline, budget, red flags. JSON.'
P2 (proposal): 'Write a 150-word Upwork proposal. Show I already solved 30% of it. One question.'
P3 (price): 'Given {hours} at ${rate}, propose 3 pricing models: fixed, hourly, milestone.'
P4 (close): 'Write a 1-line message to ask for the kickoff call without sounding needy.'
