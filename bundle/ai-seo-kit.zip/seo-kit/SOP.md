# SEO Kit SOP
1. Add target keywords to KW_SOURCE feed.
2. Run SEO Publish Pipeline daily.
3. Check index status weekly (site:yourdomain.com).
4. Audit internal links monthly.
Never promise rankings - sell the pipeline.
