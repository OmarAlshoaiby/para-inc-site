import re
# Map anchor text -> target URL for automated internal linking.
LINKS = {'automation': 'https://example.com/automation', 'ai': 'https://example.com/ai'}
def link(text):
    for k,v in LINKS.items():
        text = re.sub(r'\\b'+k+r'\\b', f'[{k}]({v})', text, count=1)
    return text
print(link('We use automation and ai daily.'))
