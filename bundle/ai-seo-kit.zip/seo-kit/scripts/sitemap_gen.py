import os
# Generate a sitemap from a list of published URLs.
URLS = ['https://example.com/p1', 'https://example.com/p2']
xml = '<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + ''.join(f'<url><loc>{u}</loc></url>' for u in URLS) + '</urlset>'
open('sitemap.xml','w').write(xml)
print('wrote sitemap.xml')
