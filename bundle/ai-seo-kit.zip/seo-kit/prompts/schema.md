# Schema / FAQ Prompt
Generate JSON-LD FAQ schema for the article: 3 question/answer pairs, under 60 words each.
