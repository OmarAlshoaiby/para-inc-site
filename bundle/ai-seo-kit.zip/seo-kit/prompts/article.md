# E-E-A-T Article Prompt
You are an expert writer. From the keyword and outline, write a 1200-word article.
Sections: Intro (hook with data), How (steps), Why (benefit), FAQ (3 Q). Tone: confident, no fluff.
Output Markdown with H2/H3 headings and one internal link placeholder [[REL]].
