# Faceless Script Prompt
Write a 180-word YouTube script for niche: {niche}. Structure: 3s hook (curiosity gap), 3 points, 5s CTA to subscribe. No face, no voice reveal.
