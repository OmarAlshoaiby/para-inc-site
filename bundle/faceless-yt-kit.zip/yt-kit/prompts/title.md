# Title + Thumbnail Copy
Generate 5 title options (under 60 chars) + 3 thumbnail text overlays (2-3 words, high contrast) for the script.
