# Upload Checklist
- [ ] Script generated
- [ ] TTS voice consistent
- [ ] Thumbnail 1280x720, 2-3 word overlay
- [ ] Title <60 chars, curiosity gap
- [ ] Upload cadence: 1/day until 30 videos
- [ ] Monetization threshold: 1k subs + 4k watch hrs
