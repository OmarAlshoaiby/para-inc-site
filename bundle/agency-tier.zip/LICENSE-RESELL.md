# Para-Inc Agency License
Buyer may resell the bundled products to clients. Keep Para-Inc attribution. No source-code redistribution of this license file.
Includes: Starter Pack, Side-Hustle, Prompt Pack, n8n Bundle, AI SEO Kit, Faceless YT Kit, plus a client-reporting workflow.
