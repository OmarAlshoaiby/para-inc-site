# Troubleshooting (15 common errors)
1. 'Could not connect' - check API key in CREDENTIALS.md.
2. 'Execution timeout' - raise timeout in workflow settings.
3. 'Invalid JSON' - re-download the .json, do not edit in a word processor.
4. 'Telegram 403' - bot not added to chat or wrong TG_CHAT.
5. 'Sheet not found' - SHEET_ID is the long id in the URL.
6. 'Gmail scope error' - re-auth with full Gmail scope.
7. 'Webhook 404' - path must match exactly, n8n must be public (use cloudflared).
8. 'Rate limit' - add a 'Wait' node between calls.
9. 'Node not found' - update n8n to latest version.
10. 'Empty output' - check the trigger actually fires (test manually).
11. 'Discord 401' - invalid webhook url.
12. 'Env var undefined' - restart n8n after editing .env.
13. 'Cron did not run' - scheduleTrigger needs n8n running 24/7.
14. 'Code node error' - check JS syntax in a linter.
15. 'Import loops' - disable before re-importing to avoid duplicates.
