# Credentials checklist
- Telegram: create bot via @BotFather, set TG_CHAT (your chat id).
- Gmail: connect Google account in n8n, create label 'Invoices'.
- Google Sheets: share a sheet, paste SHEET_ID.
- Discord: create webhook, paste DISCORD_CH id.
- Email: configure SMTP or use n8n email node with your provider.
