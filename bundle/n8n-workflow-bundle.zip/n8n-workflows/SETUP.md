# Para-Inc n8n Workflow Bundle - Setup

1. Install n8n: `npx n8n` or use docker-compose.yml below.
2. Open http://localhost:5678 -> Settings -> Import -> select a .json file.
3. Fill credentials per CREDENTIALS.md.
4. Activate the workflow.

Each workflow reads env vars (see .env.example). Copy .env.example to .env and fill values.
